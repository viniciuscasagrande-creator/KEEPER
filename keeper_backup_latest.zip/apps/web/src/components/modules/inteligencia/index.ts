export * from './InteligenciaModuleView';
