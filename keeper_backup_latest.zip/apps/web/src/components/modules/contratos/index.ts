export * from './ContratosModuleView';
