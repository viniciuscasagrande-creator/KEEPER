export * from './ComprasModuleView';
