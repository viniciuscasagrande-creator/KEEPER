export * from './AtivosModuleView';
