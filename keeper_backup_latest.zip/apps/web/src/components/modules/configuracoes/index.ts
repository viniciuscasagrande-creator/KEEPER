export * from './ConfiguracoesModuleView';
