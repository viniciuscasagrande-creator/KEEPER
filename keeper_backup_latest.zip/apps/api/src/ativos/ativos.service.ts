import { Injectable } from '@nestjs/common';
import { PrismaService } from '../common/prisma/prisma.service';

export type AssetCategory =
  | 'CATRACA_ELETRONICA'
  | 'PDA_COLETOR_MOVEL'
  | 'PDV_IMPRESSORA'
  | 'SERVIDOR_EDGE'
  | 'INFRA_REDE_NOBREAK';

export type AssetStatus =
  | 'DISPONIVEL'
  | 'EM_OPERACAO'
  | 'EM_TRANSITO'
  | 'EM_MANUTENCAO'
  | 'COMODATO_PRODUTOR'
  | 'BAIXADO';

export interface HardwareAsset {
  id: string;
  tagNumber: string; // Ex: ATV-0142
  serialNumber: string;
  model: string;
  category: AssetCategory;
  status: AssetStatus;
  currentLocation: string; // Ex: Galpão Central, Teatro Positivo, Pedreira
  venueAssigned?: string;
  producerAssigned?: string;
  purchaseDate: string;
  acquisitionValue: number;
  residualValue: number;
  healthPercent: number;
  batteryHealthPercent?: number;
  firmwareVersion: string;
  lastMaintenanceDate?: string;
  nextCalibrationDate: string;
  createdAt: string;
}

export interface MaintenanceOrder {
  id: string;
  orderNumber: string;
  assetId: string;
  assetTag: string;
  type: 'PREVENTIVA' | 'CORRETIVA' | 'CALIBRACAO';
  priority: 'ALTA' | 'NORMAL' | 'BAIXA';
  description: string;
  technicianName: string;
  status: 'ABERTA' | 'EM_EXECUCAO' | 'CONCLUIDA';
  openedAt: string;
  completedAt?: string;
}

export interface AtivosMetrics {
  totalAssets: number;
  turnstilesCount: number;
  pdasCount: number;
  pdvsCount: number;
  inOperationCount: number;
  inMaintenanceCount: number;
  totalPatrimonialValue: number;
  maintenanceHealthScore: number;
}

const SEED_ASSETS: HardwareAsset[] = [
  {
    id: 'atv-01',
    tagNumber: 'ATV-0101',
    serialNumber: 'CT-2025-99812',
    model: 'Catraca Eletrônica Pedestal Disk High-Speed v4',
    category: 'CATRACA_ELETRONICA',
    status: 'EM_OPERACAO',
    currentLocation: 'Teatro Fernanda Montenegro (Curitiba)',
    venueAssigned: 'Teatro Fernanda Montenegro',
    purchaseDate: '2025-03-10',
    acquisitionValue: 14500.0,
    residualValue: 12200.0,
    healthPercent: 98,
    firmwareVersion: 'v4.2.1-prod',
    lastMaintenanceDate: '2026-09-15',
    nextCalibrationDate: '2026-12-15',
    createdAt: '2025-03-10T10:00:00.000Z',
  },
  {
    id: 'atv-02',
    tagNumber: 'ATV-0102',
    serialNumber: 'CT-2025-99813',
    model: 'Catraca Eletrônica Pedestal Disk High-Speed v4',
    category: 'CATRACA_ELETRONICA',
    status: 'EM_OPERACAO',
    currentLocation: 'Teatro Fernanda Montenegro (Curitiba)',
    venueAssigned: 'Teatro Fernanda Montenegro',
    purchaseDate: '2025-03-10',
    acquisitionValue: 14500.0,
    residualValue: 12200.0,
    healthPercent: 97,
    firmwareVersion: 'v4.2.1-prod',
    lastMaintenanceDate: '2026-09-15',
    nextCalibrationDate: '2026-12-15',
    createdAt: '2025-03-10T10:00:00.000Z',
  },
  {
    id: 'atv-03',
    tagNumber: 'ATV-0240',
    serialNumber: 'PDA-ZB-77821',
    model: 'PDA Coletor Industrial Zebra TC26 Android',
    category: 'PDA_COLETOR_MOVEL',
    status: 'EM_OPERACAO',
    currentLocation: 'Teatro Fernanda Montenegro (Curitiba)',
    venueAssigned: 'Teatro Fernanda Montenegro',
    purchaseDate: '2025-08-20',
    acquisitionValue: 4800.0,
    residualValue: 3900.0,
    healthPercent: 95,
    batteryHealthPercent: 96,
    firmwareVersion: 'Android 13 / App Disk v2.8',
    lastMaintenanceDate: '2026-08-10',
    nextCalibrationDate: '2026-11-10',
    createdAt: '2025-08-20T14:00:00.000Z',
  },
  {
    id: 'atv-04',
    tagNumber: 'ATV-0155',
    serialNumber: 'CT-PORT-4401',
    model: 'Catraca Portátil de Alumínio Dobrável com Braço Articulado',
    category: 'CATRACA_ELETRONICA',
    status: 'DISPONIVEL',
    currentLocation: 'Galpão Central Disk (Almoxarifado Curitiba)',
    purchaseDate: '2025-05-12',
    acquisitionValue: 12800.0,
    residualValue: 10400.0,
    healthPercent: 100,
    firmwareVersion: 'v4.2.1-prod',
    lastMaintenanceDate: '2026-09-29',
    nextCalibrationDate: '2026-12-29',
    createdAt: '2025-05-12T09:00:00.000Z',
  },
  {
    id: 'atv-05',
    tagNumber: 'ATV-0310',
    serialNumber: 'SRV-EDGE-01',
    model: 'Micro-Servidor Local Edge Cache Disk com No-Break 3kVA',
    category: 'SERVIDOR_EDGE',
    status: 'DISPONIVEL',
    currentLocation: 'Galpão Central Disk (Laboratório de TI)',
    purchaseDate: '2025-11-05',
    acquisitionValue: 18500.0,
    residualValue: 15800.0,
    healthPercent: 100,
    firmwareVersion: 'Ubuntu Linux 24.04 LTS / EdgeGateway v2',
    lastMaintenanceDate: '2026-10-01',
    nextCalibrationDate: '2027-01-01',
    createdAt: '2025-11-05T11:00:00.000Z',
  },
  {
    id: 'atv-06',
    tagNumber: 'ATV-0188',
    serialNumber: 'ELG-TH-9912',
    model: 'Impressora Térmica de Bilheteria Elgin i9 USB/Serial',
    category: 'PDV_IMPRESSORA',
    status: 'EM_MANUTENCAO',
    currentLocation: 'Laboratório Técnico (Bancada 2)',
    purchaseDate: '2024-09-18',
    acquisitionValue: 1200.0,
    residualValue: 750.0,
    healthPercent: 78,
    firmwareVersion: 'v1.14',
    lastMaintenanceDate: '2026-10-08',
    nextCalibrationDate: '2026-10-25',
    createdAt: '2024-09-18T16:00:00.000Z',
  },
];

const SEED_ORDERS: MaintenanceOrder[] = [
  {
    id: 'os-01',
    orderNumber: 'OS-2026/041',
    assetId: 'atv-06',
    assetTag: 'ATV-0188',
    type: 'CORRETIVA',
    priority: 'ALTA',
    description: 'Substituição da cabeça térmica de impressão e calibração de sensor de bobina',
    technicianName: 'Rodrigo Medeiros (Técnico Eletrônico)',
    status: 'EM_EXECUCAO',
    openedAt: '2026-10-08 14:20',
  },
  {
    id: 'os-02',
    orderNumber: 'OS-2026/042',
    assetId: 'atv-04',
    assetTag: 'ATV-0155',
    type: 'PREVENTIVA',
    priority: 'NORMAL',
    description: 'Revisão periódica de rolamentos do tripé e limpeza óptica do leitor de QR Code',
    technicianName: 'Carlos Mendonça',
    status: 'CONCLUIDA',
    openedAt: '2026-09-29 09:00',
    completedAt: '2026-09-29 11:30',
  },
];

@Injectable()
export class AtivosService {
  private assets = [...SEED_ASSETS];
  private orders = [...SEED_ORDERS];

  constructor(private readonly prisma: PrismaService) {}

  async getMetrics(): Promise<AtivosMetrics> {
    const totalAssets = this.assets.length + 342; // Base de 348 ativos
    const turnstilesCount = 47;
    const pdasCount = 82;
    const pdvsCount = 64;
    const inOperationCount = 42;
    const inMaintenanceCount = this.assets.filter((a) => a.status === 'EM_MANUTENCAO').length + 1;
    const totalPatrimonialValue = 1845000.0;

    return {
      totalAssets,
      turnstilesCount,
      pdasCount,
      pdvsCount,
      inOperationCount,
      inMaintenanceCount,
      totalPatrimonialValue,
      maintenanceHealthScore: 97.4,
    };
  }

  async listAssets(): Promise<HardwareAsset[]> {
    return this.assets;
  }

  async listMaintenanceOrders(): Promise<MaintenanceOrder[]> {
    return this.orders;
  }

  async getAssetById(id: string): Promise<HardwareAsset> {
    const found = this.assets.find((a) => a.id === id);
    if (!found) throw new Error(`Ativo ${id} não encontrado`);
    return found;
  }

  async createAsset(payload: Partial<HardwareAsset>): Promise<HardwareAsset> {
    const count = this.assets.length + 343;
    const newAsset: HardwareAsset = {
      id: `atv-${Date.now()}`,
      tagNumber: `ATV-${String(count).padStart(4, '0')}`,
      serialNumber: payload.serialNumber || `SN-${Date.now().toString().slice(-6)}`,
      model: payload.model || 'Equipamento de Bilheteria Disk',
      category: payload.category || 'CATRACA_ELETRONICA',
      status: payload.status || 'DISPONIVEL',
      currentLocation: payload.currentLocation || 'Galpão Central Disk',
      purchaseDate: payload.purchaseDate || new Date().toISOString().split('T')[0],
      acquisitionValue: payload.acquisitionValue || 12000.0,
      residualValue: payload.residualValue || payload.acquisitionValue || 12000.0,
      healthPercent: 100,
      firmwareVersion: payload.firmwareVersion || 'v4.2.1-prod',
      nextCalibrationDate: '2027-01-15',
      createdAt: new Date().toISOString(),
    };
    this.assets.unshift(newAsset);
    return newAsset;
  }

  async updateAssetStatus(id: string, status: AssetStatus, location?: string): Promise<HardwareAsset> {
    const asset = await this.getAssetById(id);
    asset.status = status;
    if (location) asset.currentLocation = location;
    return asset;
  }

  async createOrder(payload: Partial<MaintenanceOrder>): Promise<MaintenanceOrder> {
    const count = this.orders.length + 43;
    const newOrder: MaintenanceOrder = {
      id: `os-${Date.now()}`,
      orderNumber: `OS-2026/${String(count).padStart(3, '0')}`,
      assetId: payload.assetId || 'atv-01',
      assetTag: payload.assetTag || 'ATV-0101',
      type: payload.type || 'PREVENTIVA',
      priority: payload.priority || 'NORMAL',
      description: payload.description || 'Manutenção técnica de rotina',
      technicianName: payload.technicianName || 'Rodrigo Medeiros',
      status: 'ABERTA',
      openedAt: new Date().toLocaleString('pt-BR'),
    };
    this.orders.unshift(newOrder);
    return newOrder;
  }
}
