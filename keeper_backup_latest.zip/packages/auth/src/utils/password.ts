import * as bcrypt from 'bcryptjs';

export class PasswordHasher {
  private static readonly SALT_ROUNDS = 10;

  public static async hash(password: string): Promise<string> {
    return bcrypt.hash(password, this.SALT_ROUNDS);
  }

  public static async compare(plainText: string, hashed: string): Promise<boolean> {
    return bcrypt.compare(plainText, hashed);
  }
}
